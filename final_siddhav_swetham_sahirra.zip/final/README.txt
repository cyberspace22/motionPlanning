
Hide 'n' Eat
- Siddharth Verma, Sanghamitra Ahirrao, Swetha Mahadevan

Main program : main.py
Obstacle program : obstacle.py
Astar algorithm : astar.py
Power Law model : powerlaw.py

Execute main.py to run the game. 
 
